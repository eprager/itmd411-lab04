/*
 * Emma Prager
 * 03/30/2019
 * BankRecordsTest.java
 * Lab 03
 */

/*
public class BankRecordsTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BankRecords test = new BankRecords();
		test.readData();
	}

}
*/
